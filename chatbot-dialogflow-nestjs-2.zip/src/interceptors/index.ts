import { TestInterceptor } from './test.interceptor';

export {
  TestInterceptor,
}
