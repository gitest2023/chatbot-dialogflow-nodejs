import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { AppController } from './app.controller';
import { ChatbotModule } from './modules/chatbot/chatbot.module';
import { TrainedDataService } from './shared';


@Module({
  imports: [ChatbotModule],
  controllers: [AppController],
  providers: [TrainedDataService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(/***** middleware classes here *****/)
      .exclude(/***** ignored routes ******/)
      .forRoutes('*' /***** verified routes, controlers,... *****/);
  }
}

