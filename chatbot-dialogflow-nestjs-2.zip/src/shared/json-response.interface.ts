export interface JsonResponse<T, E> {
  success: boolean;
  status: number;
  data?: T;
  error_messages?: E;
}
