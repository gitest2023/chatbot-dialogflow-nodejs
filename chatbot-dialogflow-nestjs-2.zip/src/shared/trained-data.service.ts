import { Injectable } from '@nestjs/common';
import { NlpManager } from 'node-nlp';

@Injectable()
export class TrainedDataService {

  private manager: NlpManager;

  constructor() {
    this.manager = new NlpManager({ languages: ["en"] });
    this.manager.load(process.cwd() + '/' + process.env.MODEL_PATH);
  }

  async process(lang: string, line: string) {
    return await this.manager.process(lang, line);
  }
}
