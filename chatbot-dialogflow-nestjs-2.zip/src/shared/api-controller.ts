import { HttpStatus, Logger } from "@nestjs/common";
import { ApiResponse } from "./api-response.service";
import { ErrorResponse } from './error-response.interface';
import { JsonResponse } from "./json-response.interface";

export class ApiController {

  protected readonly logger = new Logger((this as {}).constructor.name);
  private apiResponse = new ApiResponse<any, ErrorResponse>();

  protected successResponse(data: any, status: number = HttpStatus.OK): JsonResponse<any, ErrorResponse> {
    return this.apiResponse.success(data, status);
  }

  protected errorResponse(errors: any, status: number = HttpStatus.BAD_REQUEST): JsonResponse<any, ErrorResponse> {
    return this.apiResponse.error(errors, status);
  }

}
