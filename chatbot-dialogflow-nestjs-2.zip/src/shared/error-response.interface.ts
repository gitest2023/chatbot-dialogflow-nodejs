export interface ErrorResponse {
  [key: string]: string | number | undefined | null;
}
