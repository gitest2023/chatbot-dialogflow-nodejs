import { TestPipe } from './test.pipe';

export {
  TestPipe,
}
