import { HttpStatus, Injectable } from '@nestjs/common';
import { JsonResponse } from './json-response.interface';

@Injectable()
export class ApiResponse<T, E> {
  success(data?: T, status: number = HttpStatus.OK): JsonResponse<T, E> {
    return {
      success: true,
      status,
      data,
    };
  }
  error(errors?: E, status: number = HttpStatus.BAD_REQUEST): JsonResponse<T, E> {
    return {
      success: false,
      status,
      error_messages: errors,
    };
  }
}
