import { TestDecorator } from './test.decorator';

export {
  TestDecorator,
}
