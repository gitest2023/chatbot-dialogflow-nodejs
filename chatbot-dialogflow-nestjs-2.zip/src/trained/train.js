const { NlpManager } = require('node-nlp');
const fs = require('fs');

const manager = new NlpManager({
	languages: ["en", "vi"],
});

const files = fs.readdirSync(`${process.cwd()}/src/trained/intents`);
// const files = fs.readdirSync(`./intents`);

for (const file of files) {
	let data = fs.readFileSync(`${process.cwd()}/src/trained/intents/${file}`);
	// let data = fs.readFileSync(`./intents/${file}`);
	data = JSON.parse(data.toString());
	console.log('data => ', data)

	const intent = file.replace(".json", "");

	for (const question of data.questions) {
		manager.addDocument("en", question, intent);
	}

	for (const answer of data.answers) {
		manager.addAnswer("en", intent, answer);
	}
}

const files2 = fs.readdirSync(`${process.cwd()}/src/trained/langs`);
// const files2 = fs.readdirSync(`./langs`);

for (const file of files2) {
	let data = fs.readFileSync(`${process.cwd()}/src/trained/langs/${file}`);
	// let data = fs.readFileSync(`./langs/${file}`);
	data = JSON.parse(data);
	console.log('data => ', data)

	const intent = file.replace(".json", "");

	for (const question of data.questions) {
		manager.addDocument("vi", question, intent);
	}

	for (const answer of data.answers) {
		manager.addAnswer("vi", intent, answer);
	}
}

(async () => {
  console.log("training...");
	await manager.train();
  console.log("trained");
	manager.save(`${process.cwd()}/src/model.nlp`);
})();
