import { INestApplication } from "@nestjs/common";
import { HttpAdapterHost } from "@nestjs/core";
import { AppException } from "src/exception";
import { TestGuard } from "src/guards";
import { TestInterceptor } from "src/interceptors";
import { loggerMiddleware } from "src/middlewares";

export const registerGlobals = (app: INestApplication) => {
  // Functional middlewares
  app.use(
    loggerMiddleware,
  );
  app.useGlobalInterceptors(new TestInterceptor());
  app.useGlobalFilters(new AppException(app.get(HttpAdapterHost)));
  app.useGlobalGuards(new TestGuard);
};
