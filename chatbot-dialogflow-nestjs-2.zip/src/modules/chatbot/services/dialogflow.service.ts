import { AgentsClient, IntentsClient } from '@google-cloud/dialogflow';
import { Injectable } from '@nestjs/common';

// Credentials
const CREDENTIALS = JSON.parse(process.env.CREDENTIALS);

@Injectable()
export class DialogflowService {

  constructor(
    private agentClient: AgentsClient,
    private intentClient: IntentsClient
  ) {}

  async createAgent(name: string): Promise<void> {
    const parent = 'projects/' + CREDENTIALS.project_id + '/locations/global';
    const agent = {
      parent: parent,
      displayName: name,
      defaultLanguageCode: process.env.DEFAULT_LANG_CODE,
      timeZone: process.env.TIME_ZONE_AGENT,
    }
    await this.agentClient.setAgent({ agent });
  }

  async deleteAgent(agent: string): Promise<void> {
    await this.agentClient.deleteAgent({
      parent: `projects/${CREDENTIALS.project_id}/${agent}`
    })
  }

  // async createIntent(displayName: string) {
  //   // Construct request

  //   // The path to identify the agent that owns the created intent.
  //   const agentPath = this.intentClient.projectAgentPath(CREDENTIALS.project_id);

  //   const trainingPhrases = [];

  //   trainingPhrasesParts.forEach(trainingPhrasesPart => {
  //     const part = {
  //       text: trainingPhrasesPart,
  //     };

  //     // Here we create a new training phrase for each provided part.
  //     const trainingPhrase = {
  //       type: 'EXAMPLE',
  //       parts: [part],
  //     };

  //     trainingPhrases.push(trainingPhrase);
  //   });

  //   const messageText = {
  //     text: messageTexts,
  //   };

  //   const message = {
  //     text: messageText,
  //   };

  //   const intent = {
  //     displayName,
  //     trainingPhrases: trainingPhrases,
  //     messages: [message],
  //   };

  //   const createIntentRequest = {
  //     parent: agentPath,
  //     intent: intent,
  //   };

  //   // Create the intent
  //   const [response] = await this.intentClient.createIntent(createIntentRequest);
  //   console.log(`Intent ${response.name} created`);
  // }
}
