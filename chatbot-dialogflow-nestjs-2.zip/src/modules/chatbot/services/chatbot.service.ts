import { Injectable } from '@nestjs/common';
import { SessionsClient } from '@google-cloud/dialogflow';
import { AnswerAskBotDto } from './../dto/answer-ask-bot.dto';
import { TrainedDataService } from 'src/shared';

// Credentials
const CREDENTIALS = JSON.parse(process.env.CREDENTIALS);

// Client configuration
const CONFIGURATION = {
  credentials: {
    private_key: CREDENTIALS['private_key'],
    client_email: CREDENTIALS['client_email']
  }
}

// Create a new session
const sessionClient = new SessionsClient(CONFIGURATION);

@Injectable()
export class ChatbotService {

  constructor(
    private trainedDataService: TrainedDataService
  ) {}

  async detectIntent(answerAskBotDto: AnswerAskBotDto) {

    let sessionPath = sessionClient.projectAgentSessionPath(CREDENTIALS.project_id, answerAskBotDto.sessionId);

    // The text query request.
    let request = {
      session: sessionPath,
      queryInput: {
        text: {
          // The query to send to the dialogflow agent
          text: answerAskBotDto.queryText,
          // The language used by the client (en-US)
          languageCode: answerAskBotDto.languageCode,
        },
      },
    };

    // Send request and log result
    const responses = await sessionClient.detectIntent(request);
    console.log(responses);
    const result = responses[0].queryResult;

    // Process business command

    return result;
  }

  async detectIntentFromMyModel(answerAskBotDto: AnswerAskBotDto) {

    let response = await this.trainedDataService.process(answerAskBotDto.languageCode, answerAskBotDto.queryText);
    console.log(response)
    return response.answer;
  }
}
