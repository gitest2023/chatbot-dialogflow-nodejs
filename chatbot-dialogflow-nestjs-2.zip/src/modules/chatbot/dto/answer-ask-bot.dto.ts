import { IsString, Length } from "class-validator";

export class AnswerAskBotDto {
  @IsString()
  @Length(1, 1)
  languageCode: string;

  @IsString()
  queryText: string;

  @IsString()
  sessionId: string;
}
