import { Body, Controller, Post, Get } from '@nestjs/common';
import { ApiController } from 'src/shared/api-controller';
import { ErrorResponse } from 'src/shared/error-response.interface';
import { JsonResponse } from 'src/shared/json-response.interface';
import { AnswerAskBotDto } from '../dto/answer-ask-bot.dto';
import { ChatbotService } from '../services/chatbot.service';

@Controller('api/bots')
export class ChatbotController extends ApiController {

  constructor(
    private botService: ChatbotService,
  ) { super(); }

  @Post()
  async create(@Body() answerAskBotDto: AnswerAskBotDto): Promise<JsonResponse<string, ErrorResponse>> {
    this.logger.log('params => {0}', answerAskBotDto);
    return this.successResponse(await this.botService.detectIntentFromMyModel(answerAskBotDto));
  }
}
