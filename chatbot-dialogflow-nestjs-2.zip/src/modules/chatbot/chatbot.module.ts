import { Module } from '@nestjs/common';
import { TrainedDataService } from 'src/shared';
import { ChatbotController } from './controllers/chatbot.controller';
import { ChatbotService } from './services/chatbot.service';

@Module({
  controllers: [ChatbotController],
  providers: [ChatbotService, TrainedDataService]
})
export class ChatbotModule {}
