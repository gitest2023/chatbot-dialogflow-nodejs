export class Sample {}
