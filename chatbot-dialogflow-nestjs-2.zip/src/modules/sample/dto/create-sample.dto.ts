export class CreateSampleDto {}
