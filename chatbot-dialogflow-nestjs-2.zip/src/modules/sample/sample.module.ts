import { Module } from '@nestjs/common';
import { SampleService } from './services/sample.service';
import { SampleController } from './controllers/sample.controller';

@Module({
  controllers: [SampleController],
  providers: [SampleService]
})
export class SampleModule {}
