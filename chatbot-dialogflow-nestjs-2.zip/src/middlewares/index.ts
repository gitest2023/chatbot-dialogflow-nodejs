import { loggerMiddleware, LoggerMiddleware } from './logger.middleware';

export {
  LoggerMiddleware,
  loggerMiddleware,
}
