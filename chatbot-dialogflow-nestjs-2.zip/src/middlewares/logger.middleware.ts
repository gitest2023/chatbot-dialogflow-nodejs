import { Injectable, NestMiddleware } from '@nestjs/common';
import { NextFunction, Request, Response } from 'express';

/**
 * Class Middleware
 */
@Injectable()
export class LoggerMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: Function) {
    console.log('[LoggerMiddleware] Request...');
    // throw new Error('Test middleware')
    next();
  }
}

/**
 * Functional Middleware
 *
 * @param req Request
 * @param res Response
 * @param next NextFunction
 */
export function loggerMiddleware(req: Request, res: Response, next: NextFunction) {
  console.log(`[Functional Middleware][Before] Request => `);
  // throw new Error('Test middleware')
  // return res.json(ApiResponse.jsonError('test error'));
  // return new ApiResponse().useRes(res).error('test error');
  next();
  console.log(`[Functional Middleware][After] Response => `);
};
