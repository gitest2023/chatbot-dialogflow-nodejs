import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { registerGlobals } from './global';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  registerGlobals(app);

  await app.listen(3000);
}
bootstrap();
